// 자동 스크롤 기능 - autoScroll.js
